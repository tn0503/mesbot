import cv2

prevX=0
prevY=0

def onMouse(event, x, y, flags, params):
    global prevX
    global prevY
    if event == cv2.EVENT_LBUTTONDOWN:
        print('{1,',x/10,',', y/10,',','0},')
        cv2.line(img,(prevX, prevY), (x,y), (255,0,0), 10)
        cv2.imshow('pic', img)
        prevX = x
        prevY = y
    elif event == cv2.EVENT_RBUTTONDOWN:
        print('{0,',x/10,',', y/10,',','0},')
        prevX = x
        prevY = y

img = cv2.imread('pic.png')
cv2.imshow('pic', img)
cv2.setMouseCallback('pic', onMouse)
cv2.waitKey(0)